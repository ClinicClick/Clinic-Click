**PORTFÓLIO ACADÊMICO – VITÓRIA DA SILVA ALMEIDA**

---

### 📌 Dados Pessoais
**Nome:** Vitória da Silva Almeida  
**Curso:** Arquitetura e Urbanismo  
**Instituição:** Centro Universitário Fundação Santo André  
**RA:** 761373  
**E-mail institucional:** vitoria.761373@graduacao.fsa.br

---

### 📘 Projeto Destaque: *Startup Clinic Click – Suporte Digital para Pessoas com Deficiência*

#### 🧠 Resumo do Projeto
A **Clinic Click** é uma startup social que desenvolve um **aplicativo acessível** para fornecer suporte **emocional e técnico** a pessoas com deficiência (PcD). Seu objetivo é romper barreiras de acesso à saúde, ao bem-estar psicológico e à informação, promovendo **autonomia e inclusão digital**.

---

### 🎯 Objetivos
- **Geral:** Desenvolver uma plataforma digital que atenda às necessidades reais das PcD.
- **Específicos:**
  - Conectar usuários a profissionais de saúde e suporte psicológico.
  - Oferecer recursos de acessibilidade como Libras, leitura por voz e alto contraste.
  - Disponibilizar catálogo de tecnologias assistivas.
  - Integrar prescrições médicas e dados de saúde.
  - Promover educação digital e empoderamento informacional.

---

### 🧪 Metodologia
- Abordagem **qualitativa e quantitativa**: entrevistas, questionários, oficinas e grupos focais.
- Ferramentas utilizadas:
  - **Figma** (prototipagem de interfaces),
  - **Firebase** (banco de dados),
  - **React Native** (desenvolvimento do app).
- Metodologia participativa e dialógica com usuários reais, inspirada em Paulo Freire.

---

### 🖥️ Tecnologias e Funcionalidades do MVP
- Cadastro com tipo de deficiência e prescrição médica.
- Chat com psicólogos.
- Catálogo digital de tecnologias assistivas.
- Botão de emergência.
- Acessibilidade total: leitura por voz, vídeos em Libras e alto contraste.
- Conteúdo educativo sobre direitos, saúde e cidadania.

---

### 📊 Resultados Obtidos
- **Engajamento real** com mais de 30 PcDs, 15 cuidadores e 10 profissionais da saúde.
- Protótipo validado com usuários em grupos focais.
- Criação de **cartilha digital** e vídeos educativos com depoimentos reais.
- Viabilidade econômica demonstrada com plano de negócios baseado em:
  - versão gratuita,
  - versão premium,
  - parcerias com instituições públicas e privadas.

---

### 📍 Apresentações e Reconhecimentos
- **SAPEX 2025** – com o pôster “A Jornada de Aprimoramento de uma Sociedade”.
- **Pitch Acadêmico** apresentado por Vitória, com introdução, definição do problema e apresentação da solução.
- Participação em banca avaliadora do **TCC**, com destaque para a **interação dialógica** com a comunidade PcD.

---

### 📒 Referências Técnicas e Teóricas
- Lei nº 13.146/2015 – Estatuto da Pessoa com Deficiência.
- WCAG 2.1 – Diretrizes de Acessibilidade para Conteúdo Web.
- Freire, P. – *Pedagogia do Oprimido*.
- Manzini, E. – *Acessibilidade: ampliando o acesso à educação, trabalho e vida social*.

---

### 📚 Materiais Produzidos
- Protótipos interativos do app.
- Cartilha digital sobre direitos das PcD.
- Vídeos com depoimentos de usuários.
- Blog colaborativo com experiências reais.
- Relatório técnico (TCC) completo com análise de viabilidade.

---

### 🏁 Conclusão
A participação no projeto **Clinic Click** permitiu a aplicação prática de conhecimentos acadêmicos para resolver um problema real de **exclusão digital e social**. O projeto evidenciou o papel da arquitetura e do design inclusivo na construção de uma sociedade mais acessível e equitativa.

---

**Vitória da Silva Almeida**  
Arquitetura e Urbanismo  
Centro Universitário Fundação Santo André