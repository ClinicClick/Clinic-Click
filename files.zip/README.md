# Portfólio Acadêmico – Vitória da Silva Almeida

Este repositório reúne o portfólio acadêmico de Vitória da Silva Almeida, destacando o projeto **Clinic Click – Suporte Digital para Pessoas com Deficiência**.

## Estrutura

- `portifolio_clinic_click.md` – Portfólio completo com detalhes do projeto.
- `prototipos/` – Protótipos interativos e imagens do app.
- `materiais/` – Cartilhas, vídeos educativos e outros materiais produzidos.
- `relatorios/` – Relatório técnico (TCC) e análises.
- `apresentacoes/` – Slides, pôsteres e materiais de eventos.

## Sobre o Projeto Clinic Click

Aplicativo acessível focado em suporte emocional e técnico para pessoas com deficiência, promovendo inclusão digital, autonomia e cidadania.

---

**Contato:** vitoria.761373@graduacao.fsa.br